const express = require('express');
const router = express.Router();

let tasks = [
  { id: 1, title: "Estudiar Node.js", completed: false },
  { id: 2, title: "Hacer ejercicio", completed: true }
];

// GET: Obtener todas las tareas
router.get('/', (req, res) => {
  res.json(tasks);
});

// POST: Crear una nueva tarea
router.post('/', (req, res) => {
  const newTask = {
    id: tasks.length + 1,
    title: req.body.title,
    completed: false
  };
  tasks.push(newTask);
  res.status(201).json(newTask);
});

// PUT: Actualizar una tarea
router.put('/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const task = tasks.find(t => t.id === id);

  if (task) {
    task.title = req.body.title || task.title;
    task.completed = req.body.completed !== undefined ? req.body.completed : task.completed;
    res.json(task);
  } else {
    res.status(404).json({ message: "Tarea no encontrada" });
  }
});

// GET: Obtener una sola tarea por ID
router.get('/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const task = tasks.find(t => t.id === id);
  if (task) {
    res.json(task);
  } else {
    res.status(404).json({ message: "Tarea no encontrada" });
  }
});

module.exports = router;
